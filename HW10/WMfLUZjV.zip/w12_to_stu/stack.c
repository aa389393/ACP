#include "stack.h"

tStack *create_stack(void)
{
   






}

void handle_push_operation(tStack *stack_ptr)
{


	  


	      printf ("[Error]  handle_push_operation(): space full \n");


	  
    printf("  handle_push_operation(): enter score value: ");
    scanf("%d", &score);
    

    get_score_space();




    
    return; 
}

void handle_pop_operation(tStack *stack_ptr)
{

	  


	      printf ("[Error]  handle_pop_operation(): nothing in stack = \n");


	  

	  printf("  handle_pop_operation(): poped value: %d\n", );
	  return_score_space();




}

void print_stack_content(tStack *stack_ptr)
{


    
    printf("   print_stack_content(): stack items -> ");





}

