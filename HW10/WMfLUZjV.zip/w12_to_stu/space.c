#include "space.h"

tTypeScore score_buf[N]; //preallocated memory space

void get_score_space(tTypeScore **pp_score)
{









	  printf("     get_score_space(): giving space numbered %d\n", );




    return;
}

void return_score_space (int loc)
{

    printf("     return_score_space(): return space numbered %d\n", loc);
}
