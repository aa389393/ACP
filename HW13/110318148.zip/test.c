#include<stdio.h>
#include<stdbool.h>
#define num 50
int main(){
    bool c[num];
    printf("%d", sizeof(c));
}